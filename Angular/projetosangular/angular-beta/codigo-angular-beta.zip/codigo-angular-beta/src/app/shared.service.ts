import { Injectable } from '@angular/core';
@Injectable()
export class SharedService {
  // indicando a propriedade que será utilizada para receber um determinado conteudo
  valorCompartilhado: number

  constructor() { 
    // exibir que o construtor foi chamado com sucesso
    console.log('SharedService constructor foi chamado com sucesso')

    // inicializar a propriedade com o valor
    this.valorCompartilhado = Math.round(Math.random()*100)

    // exibir o valor da propriedade no terminal do browser
    console.log(this.valorCompartilhado)
  }

  // criar uma função para ser chamada e exibir o valor da propridade nos componentes
  public  obterValorCompartilhado(){
    return this.valorCompartilhado
  }
}
