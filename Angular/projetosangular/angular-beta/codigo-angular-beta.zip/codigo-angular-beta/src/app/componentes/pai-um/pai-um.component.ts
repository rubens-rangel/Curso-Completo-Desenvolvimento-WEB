import { Component } from '@angular/core';
import { SharedService } from '../../shared.service';

@Component({
  selector: 'app-pai-um',
  templateUrl: './pai-um.component.html',
  styleUrls: ['./pai-um.component.css'],
  providers: []
})
export class PaiUmComponent{

  // criar propriedade para receber o boj referencial do service
  valorAssociado

// referenciando a instância do service
  constructor(private instService: SharedService) { 
    this.valorAssociado = instService.obterValorCompartilhado()

    // exibir o valor gerado neste componente no terminal do browser
    console.log('Valor associado ao componente pai-um: ' + this.valorAssociado.toString())
  }



}
