import { Component } from '@angular/core';
import { SharedService } from '../../shared.service';

@Component({
  selector: 'app-filho-um',
  templateUrl: './filho-um.component.html',
  styleUrls: ['./filho-um.component.css'],
  providers: []
})
export class FilhoUmComponent{

  // propriedade para receber o valor gerado pelo service
  valorAssocFI
  
  // referencia da instancia do service
  constructor(private refInstFI: SharedService) { 
    this.valorAssocFI = refInstFI.obterValorCompartilhado()

    // exibindo no terminal do browser
    console.log('Valor associado ao componente filho-um : ' + this.valorAssocFI.toString())
  }

 

}
