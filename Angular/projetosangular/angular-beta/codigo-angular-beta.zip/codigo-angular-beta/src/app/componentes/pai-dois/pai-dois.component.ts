import { Component } from '@angular/core';
import { SharedService } from '../../shared.service';

@Component({
  selector: 'app-pai-dois',
  templateUrl: './pai-dois.component.html',
  styleUrls: ['./pai-dois.component.css'],
  providers: []
})
export class PaiDoisComponent {

  // criando a propriedade para lidar com o valor gerado pelo service neste componente
  valorAssocPaiII

  // refereciando a instancia do service
  constructor(private refInstPII: SharedService) { 

    // atribuir à propriedade o valor gerado pelo service - neste componente
    this.valorAssocPaiII = this.refInstPII.obterValorCompartilhado()

    // exbixir o valo, aqui associado, no terminal do browser
    console.log('Valor associado ao componente pai-dois : ' + this.valorAssocPaiII.toString())
  }
}
