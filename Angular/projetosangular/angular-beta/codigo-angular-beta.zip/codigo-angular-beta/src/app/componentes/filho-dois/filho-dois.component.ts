import { Component } from '@angular/core';
import { SharedService } from '../../shared.service'

@Component({
  selector: 'app-filho-dois',
  templateUrl: './filho-dois.component.html',
  styleUrls: ['./filho-dois.component.css'],
  providers: []
})
export class FilhoDoisComponent {

  // propriedade
  valorAssocFII

  // referencia da instancia
  constructor(private refInstFII: SharedService) { 
    this.valorAssocFII = refInstFII.obterValorCompartilhado()

    // exibir no terminal do browser
    console.log('Valor associado ao componente FII: ' + this.valorAssocFII.toString())
  }



}
