import { Component } from '@angular/core';
import { SharedService } from './shared.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: []
})
export class AppComponent {
  title = 'angular-beta';


  // criando a propriedade para lidar com o valor gerado pelo service neste componente
  valorAssocAppComp

  // refereciando a instancia do service
  constructor(private refInstAppComp: SharedService) { 

    // atribuir à propriedade o valor gerado pelo service - neste componente
    this.valorAssocAppComp = this.refInstAppComp.obterValorCompartilhado()

    // exbixir o valo, aqui associado, no terminal do browser
    console.log('Valor associado ao componente principal : ' + this.valorAssocAppComp.toString())
  }
}
