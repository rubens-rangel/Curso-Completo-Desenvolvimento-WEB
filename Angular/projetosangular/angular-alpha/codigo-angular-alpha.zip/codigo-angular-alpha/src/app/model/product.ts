// este é o model domain
export class Produto{

    // criar as propriedades referenciando-as no construtor, inicializando-as e disponibilizando-as para o devido uso
    constructor(idProduto: number, nomeProduto: string, precoProduto:number){
        this.idProduto = idProduto
        this.nomeProduto = nomeProduto
        this.precoProduto = precoProduto
    }

    // "disponibilizando" as propriedades
    idProduto: number
    nomeProduto: string
    precoProduto: number   
}
/*
    idProduto!: number
    nomeProduto!: string
    precoProduto!: number 
*/
/*
export interface Produto{
    idProduto: number
    nomeProduto: string
    precoProduto: number
}*/