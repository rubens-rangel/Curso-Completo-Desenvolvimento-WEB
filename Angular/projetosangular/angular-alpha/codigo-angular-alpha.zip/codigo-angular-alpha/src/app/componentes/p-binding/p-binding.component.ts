import { Component } from '@angular/core';

@Component({
  selector: 'app-p-binding',
  templateUrl: './p-binding.component.html',
  styleUrls: ['./p-binding.component.css']
})
export class PBindingComponent{
  // declarando a propriedade para vincular via property-binding
  public umNumero: number = 67


}
