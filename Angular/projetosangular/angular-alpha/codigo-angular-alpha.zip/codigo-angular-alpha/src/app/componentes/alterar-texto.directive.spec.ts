import { AlterarTextoDirective } from './alterar-texto.directive';

describe('AlterarTextoDirective', () => {
  it('should create an instance', () => {
    const directive = new AlterarTextoDirective();
    expect(directive).toBeTruthy();
  });
});
