import { PipeRaizQuadradaPipe } from './pipe-raiz-quadrada.pipe';

describe('PipeRaizQuadradaPipe', () => {
  it('create an instance', () => {
    const pipe = new PipeRaizQuadradaPipe();
    expect(pipe).toBeTruthy();
  });
});
