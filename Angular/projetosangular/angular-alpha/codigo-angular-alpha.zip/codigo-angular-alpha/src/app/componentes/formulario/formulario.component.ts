import { Component } from '@angular/core';
// importando os recursos necessários
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css']
})
export class FormularioComponent{
  // criar as propriedades para controlar o formulário
  dadosForm: any
  email: any

  // chamando o hook para priorizar as intancias das classes para controlar o formulario
  ngOnInit(){
    this.dadosForm = new FormGroup({
      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('[^ @]*@[^ @]*')
      ])),
      senha: new FormControl('', this.validacaoSenha)
    })
  }

  // função para validação do campo senha
  validacaoSenha(valoresSenha: any){
    if(valoresSenha.value.length < 5){
      return{senha:true}
    }
    return null
  }

  // criar uma função para auxiliar na exibição do valor de email  oferecido ao formulario
  exibidoraDados(umDado: any): void{
    this.email = umDado.email
  }
}



/*
// criando a função para receber os dados
  recebedorDados(dadosRecebidos: any): void{
    alert('O email recebido foi : ' + dadosRecebidos.email)
  }

*/
