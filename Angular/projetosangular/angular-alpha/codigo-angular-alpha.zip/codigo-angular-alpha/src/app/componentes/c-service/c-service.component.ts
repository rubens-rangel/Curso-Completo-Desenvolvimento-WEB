import { Component } from '@angular/core';
// importando os recursos necessários
import { Produto } from '../../model/product';
import { ProductService } from 'src/app/data/product.service';

@Component({
  selector: 'app-c-service',
  templateUrl: './c-service.component.html',
  styleUrls: ['./c-service.component.css'] 
})
export class CServiceComponent{

  // casting das propriedades que serão usadas
  cestaProdutos!: Produto[]
 
  constructor(private objDoService: ProductService) { 
    //this.objDoService = new ProductService()
  }

  // criar uma função para - através do uso do objeto criado - acessar a lista de produtos criada no service
  acessandoListaProdutos(){
    this.cestaProdutos = this.objDoService.getProdutos()
  }

}
