import { Injectable } from '@angular/core';

@Injectable()

export class TestandoService {
  // criar uma função para verificar de ProductService está sendo executado corretamente
  unitario(mensagemTeste: any){
    console.log(mensagemTeste)
  }
}
