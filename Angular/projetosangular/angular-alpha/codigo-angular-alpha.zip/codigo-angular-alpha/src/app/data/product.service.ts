// importando o model
import { Produto } from "../model/product";
import { Injectable } from '@angular/core';
// importando o service testando
import { TestandoService } from "./testando.service";

@Injectable()


export class ProductService {
  
  // fazendo a refernecia de instancia do novo service
  constructor(private resultTeste: TestandoService) { 
    this.resultTeste.unitario('Construtor chamado/construido com sucesso!')
  }

  // função para retronar a lista de produtos que será "populada"
  public getProdutos(){
    this.resultTeste.unitario('Método/função getProdutos chamado com sucesso total!')

    // propriedade que será a lista de produtos
    let listaProdutos: Produto[]

    // itens que serão inseridos dentro da lista
    listaProdutos = [
      new Produto(1, 'Quadro Baby Yoda', 199),
      new Produto(2, 'Mascara Darth Vader', 159),
      new Produto(3, 'LightSaber', 89)
    ]
    this.resultTeste.unitario(listaProdutos)
    
    return listaProdutos
  }
}
